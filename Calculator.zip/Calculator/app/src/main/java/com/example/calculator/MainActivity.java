package com.example.calculator;

import android.graphics.Point;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import static java.lang.Math.sqrt;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    public void onNumberClick(View view) {
        TextView bb = findViewById(R.id.textView);
        String text = bb.getText().toString();
        if (text.equals("0")) {
            bb.setText(view.getTag().toString());
        } else if (text.length() < 12)
            bb.setText(text + view.getTag().toString());
    }

    public void onOperationClick(View view) {
        TextView bb = findViewById(R.id.textView);
        String text = bb.getText().toString();
        char[] operations = {'/', '*', '+', '-', '.'};
        if (view.getTag().toString().equals(".")) {

        }
        boolean contains = false;
        for (char operation : operations) {
            if (operation == text.charAt(text.length() - 1)) {
                contains = true;
                break;
            }
        }
        if (contains) {
            bb.setText(text.substring(0, text.length() - 1) + view.getTag());
        } else
            bb.setText(text + view.getTag().toString());
    }

    public static boolean containsChar(char[] charArray, char ch) {
        for (char c : charArray) {
            if (c == ch)
                return true;
        }
        return false;
    }

    public void onFunctionClick(View view) {
        TextView bb = findViewById(R.id.textView);
        String text = bb.getText().toString();
        switch (view.getTag().toString()) {
            case "c":
                bb.setText("0");
                break;
            case "bs":
                if (text.length() == 1) {
                    bb.setText("0");
                } else
                    bb.setText(text.subSequence(0, text.length() - 1));
                break;
            case "%":
                float res = Float.valueOf(text) / 100;
                if (res - (int) res > 0) {
                    bb.setText(String.valueOf(res));
                } else
                    bb.setText(String.valueOf((int) res));
                break;
            case "=":
                ArrayList<String> elements = new ArrayList<>();

                char[] numbersArray = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0'};
                StringBuilder element = new StringBuilder();
                for (char c : text.toCharArray()) {
                    if (containsChar(numbersArray, c)) {
                        element.append(c);
                    } else
                        elements.add(String.valueOf(element));
                }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView bb = findViewById(R.id.textView);

        Button num1 = findViewById(R.id.num1);
        Button num2 = findViewById(R.id.num2);
        Button num3 = findViewById(R.id.num3);
        Button num4 = findViewById(R.id.num4);
        Button num5 = findViewById(R.id.num5);
        Button num6 = findViewById(R.id.num6);
        Button num7 = findViewById(R.id.num7);
        Button num8 = findViewById(R.id.num8);
        Button num9 = findViewById(R.id.num9);
        Button num0 = findViewById(R.id.num0);
        Button clear = findViewById(R.id.clearButton);
        Button backspace = findViewById(R.id.backspaceButton);
        Button percent = findViewById(R.id.percentButton);
        Button divide = findViewById(R.id.divideButton);
        Button multiply = findViewById(R.id.multiplyButton);
        Button minus = findViewById(R.id.minusButton);
        Button plus = findViewById(R.id.plusButton);
        Button dot = findViewById(R.id.dotButton);
        Button result = findViewById(R.id.resultButton);

        ArrayList<Button> buttons = new ArrayList<>();
        buttons.add(num0);
        buttons.add(num1);
        buttons.add(num2);
        buttons.add(num3);
        buttons.add(num4);
        buttons.add(num5);
        buttons.add(num6);
        buttons.add(num7);
        buttons.add(num8);
        buttons.add(num9);
        buttons.add(clear);
        buttons.add(backspace);
        buttons.add(percent);
        buttons.add(divide);
        buttons.add(multiply);
        buttons.add(minus);
        buttons.add(plus);
        buttons.add(dot);
        buttons.add(result);

        Display display = ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;

        int columns = 3;
        int lines = 3;

        for (Button button : buttons) {
            button.setHeight((int) (width / sqrt(3) / columns));
        }
        ArrayList<String> calculations = new ArrayList<>();
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        bb.setText("0");

    }

    @Override
    public void onClick(View v) {
        int num;
        Operation operation;
        switch (v.getId()) {
            case R.id.num1:
                num = 1;
                break;
            case R.id.num2:
                num = 2;
                break;
            case R.id.num3:
                num = 3;
                break;
            case R.id.num4:
                num = 4;
                break;
            case R.id.num5:
                num = 5;
                break;
            case R.id.num6:
                num = 6;
                break;
            case R.id.num7:
                num = 7;
                break;
            case R.id.num8:
                num = 8;
                break;
            case R.id.num9:
                num = 9;
                break;
            case R.id.num0:
                num = 0;
                break;
            case R.id.plusButton:
                operation = Operation.PLUS;
                break;
            case R.id.minusButton:
                operation = Operation.MINUS;
                break;
            case R.id.multiplyButton:
                operation = Operation.MULTIPLY;
                break;
            case R.id.divideButton:
                operation = Operation.DIVIDE;
                break;
            case R.id.resultButton:

                break;
        }
    }

    enum Operation {
        PLUS,
        MINUS,
        MULTIPLY,
        DIVIDE
    }
}
